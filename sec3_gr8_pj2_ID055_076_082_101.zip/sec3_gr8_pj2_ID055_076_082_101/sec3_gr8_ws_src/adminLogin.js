const admin = require('AdminLogin');

const connection = admin.createConnection({
  user: 'username',
  password: 'password',
  email: 'email',
  mobile: 'mobile'
});

connection.connect((err) => {
  if (err) {
    console.error('Invalid username or password', err);
    return;
  }

  console.log('Authentication successful');
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});

function insertAdmin(firstName, lastName, email, mobile) {
    const query = `INSERT INTO admins (firstName, lastName, email, mobile) VALUES ('${firstName}', '${lastName}', '${email}', '${mobile}')`;
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error inserting admin:', err);
        return;
      }
  
      console.log('Admin inserted successfully');
    });
  }

  function searchAdmins(firstName, lastName, email, mobile) {
    let query = `SELECT * FROM admins`;
  
    if (firstName) {
      query += ` WHERE firstName='${firstName}'`;
    }
  
    if (lastName) {
      query += ` AND lastName='${lastName}'`;
    }
  
    if (email) {
      query += ` AND email='${email}'`;
    }
  
    if (mobile) {
      query += ` AND mobile='${mobile}'`;
    }
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error searching admins:', err);
        return;
      }
  
      console.log('Search results:', results);
    });
  }
  
  function updateAdmin(adminId, firstName, lastName, email, mobile) {
    const query = `UPDATE admins SET firstName='${firstName}', lastName='${lastName}', email='${email}', mobile='${mobile}' WHERE id='${adminId}'`;
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error updating admin:', err);
        return;
      }
  
      console.log('Admin updated successfully');
    });
  }
  
  function deleteAdmin(adminId) {
    const query = `DELETE FROM admins WHERE id='${adminId}'`;
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error deleting admin:', err);
        return;
      }
  
      console.log('Admin deleted successfully');
    });
  }
  function searchAdmins(firstName, lastName, email, mobile) {
    let query = `SELECT * FROM admins`;
  
    if (firstName) {
      query += ` WHERE firstName='${firstName}'`;
    }
  
    if (lastName) {
      query += ` AND lastName='${lastName}'`;
    }
  
    if (email) {
      query += ` AND email='${email}'`;
    }
  
    if (mobile) {
      query += ` AND mobile='${mobile}'`;
    }
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error searching admins:', err);
        return;
      }
  
      console.log('Search results:', results);
    });
  }
  
  function updateAdmin(adminId, firstName, lastName, email, mobile) {
    const query = `UPDATE admins SET firstName='${firstName}', lastName='${lastName}', email='${email}', mobile='${mobile}' WHERE id='${adminId}'`;
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error updating admin:', err);
        return;
      }
  
      console.log('Admin updated successfully');
    });
  }
  
  function deleteAdmin(adminId) {
    const query = `DELETE FROM admins WHERE id='${adminId}'`;
  
    connection.query(query, (err, results, fields) => {
      if (err) {
        console.error('Error deleting admin:', err);
        return;
      }
  
      console.log('Admin deleted successfully');
    });
  }
    