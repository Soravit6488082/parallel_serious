// Search and view administrators data
function searchAdmins(firstName, lastName, email, mobile) {
  let searchResults = admins;
  
  // Check if criteria is provided, and filter searchResults accordingly
  if (firstName) {
    searchResults = searchResults.filter(admin => admin.firstName === firstName);
  }
  
  if (lastName) {
    searchResults = searchResults.filter(admin => admin.lastName === lastName);
  }
  
  if (email) {
    searchResults = searchResults.filter(admin => admin.email === email);
  }
  
  if (mobile) {
    searchResults = searchResults.filter(admin => admin.mobile === mobile);
  }
  
  return searchResults;
}

  
  // Insert administrator data
  function insertAdmin(firstName, lastName, email, mobile) {
    // Check if admin with same email already exists
    if (adminWithEmailExists(email)) {
      return "Admin with email already exists";
    }
  
    // Generate unique ID for new admin
    const newAdminId = generateNewAdminId();
  
    // Create new admin object
    const newAdmin = {
      id: newAdminId,
      firstName: firstName,
      lastName: lastName,
      email: email,
      mobile: mobile
    };
  
    // Add new admin to the system
    addAdminToSystem(newAdmin);
  
    // Return success message with new admin ID
    return "Admin with ID " + newAdminId + " has been added successfully";
  }
  
  
  // Update administrator data
  function updateAdmin(adminId, firstName, lastName, email, mobile) {
    // First, check if the admin exists in the system
    if (!adminExists(adminId)) {
      return { success: false, message: "Admin does not exist in the system" };
    }
  
    // Update the admin's information in the system
    for (let i = 0; i < admins.length; i++) {
      if (admins[i].id === adminId) {
        admins[i].firstName = firstName;
        admins[i].lastName = lastName;
        admins[i].email = email;
        admins[i].mobile = mobile;
        return { success: true, message: "Admin updated successfully" };
      }
    }
  
    // Return an error message if the update was not successful
    return { success: false, message: "Unable to update admin information" };
  }
  
  
  // Delete administrator data
  function deleteAdmin(adminId) {
    // Code to delete admin with the given adminId from the system
    // Return true if deletion was successful, false otherwise
    // For example:
    if (adminId in adminDatabase) {
      delete adminDatabase[adminId];
      return true;
    } else {
      return false;
    }
  }


//Test cases for searchAdmins:

//Test case when all criteria are provided:
Input: searchAdmins("John", "Doe", "johndoe@example.com", "1234567890");
//Expected output: Returns an array of admins that match all the provided criteria, if any.

//Test case when only one criterion is provided:
Input: searchAdmins("", "", "johndoe@example.com", "");
//Expected output: Returns an array of admins that match the provided email criterion, if any.

//Test cases for insertAdmin:

//Test case when admin with the same email already exists:
Input: insertAdmin("Jane", "Doe", "johndoe@example.com", "9876543210");
//Expected output: Returns the message "Admin with email already exists".

//Test case when a new admin is successfully added:
Input: insertAdmin("Jane", "Doe", "janedoe@example.com", "9876543210");
//Expected output: Returns the message "Admin with ID [newAdminId] has been added successfully", where [newAdminId] is the ID generated for the new admin.

//Test cases for updateAdmin:

//Test case when admin exists and update is successful:
Input: updateAdmin("1", "John", "Doe", "johndoe@example.com", "9876543210");
//Expected output: Returns an object with the properties { success: true, message: "Admin updated successfully" }.

//Test case when admin does not exist:
Input: updateAdmin("10", "John", "Doe", "johndoe@example.com", "9876543210");
//Expected output: Returns an object with the properties { success: false, message: "Admin does not exist in the system" }.

//Test cases for deleteAdmin:

//Test case when admin with given ID exists and deletion is successful:
Input: deleteAdmin("1");
//Expected output: Returns true.

//Test case when admin with given ID does not exist:
Input: deleteAdmin("10");
//Expected output: Returns false.
  
  