const express = require('express');
const app = express();

// Authentication endpoint
app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  // Validate credentials
  if (username === 'admin' && password === 'password') {
    // Generate and return token or session ID
    const token = generateToken();
    res.json({ token });
  } else {
    res.status(401).json({ error: 'Invalid username or password' });
  }
});

function generateToken() {
  // Generate a unique token or session ID
  return 'username';
}

app.listen(3000, () => console.log('Server started on port 3000'));



// Search
app.get('/admin/products', (req, res) => {
    const { Name, price, description } = req.query;
    // Query database for products matching criteria
    const products = queryDatabase(Name, price, description);
    res.json(products);
  });
// Test case 1: No criteria search
// Expected outcome: Returns all products or services in the system
searchProducts();

// Test case 2: Criteria search with one criteria
// Expected outcome: Returns products or services that match the given criteria
// Search by name: "Samsung"
searchProducts("Samsung");  


  // Insert
  app.post('/admin/products', (req, res) => {
    const { name, price, description } = req.body;
    // Insert product into database
    insertProduct(name, price, description);
    res.sendStatus(200);
  });
  // Test case 1: Valid product or service data
// Expected outcome: Returns success message and new product or service ID
// Product or service data: { name: "New Product", price: 25000, category: "Samsung" }
insertProduct({ name: "New Product", price: 25000, category: "Samsung" });

// Test case 2: Invalid product or service data
// Expected outcome: Returns error message
// Product or service data: { name: "", price: 10000, category: "Samsung" }
insertProduct({ name: "", price: 10000, category: "Samsung" });


  // Update
  app.put('/admin/products/:id', (req, res) => {
    const { id } = req.params;
    const { name, price, description } = req.body;
    // Update product in database
    updateProduct(id, name, price, description);
    res.sendStatus(200);
  });
  // Test case 1: Valid product or service ID and data
// Expected outcome: Returns success message
// Product or service ID: 123, Updated data: { name: "Samsung", price: 30, Quantity: "2" }
updateProduct(123, { name: "Samsung", price: 30, Quantity: 2 });

// Test case 2: Invalid product or service ID or data
// Expected outcome: Returns error message
// Product or service ID: "abc", Updated data: { name: "", price: 20, Quantity: "4" }
updateProduct("abc", { name: "", price: 20, Quantity: 4 });
  

  // Delete
  app.delete('/admin/products/:id', (req, res) => {
    const { id } = req.params;
    // Delete product from database
    deleteProduct(id);
    res.sendStatus(200);
  });
  // Test case 1: Valid product or service ID
// Expected outcome: Returns success message
// Product or service ID: 456
deleteProduct(456);

// Test case 2: Invalid product or service ID
// Expected outcome: Returns error message
// Product or service ID: "xyz"
deleteProduct("xyz");

