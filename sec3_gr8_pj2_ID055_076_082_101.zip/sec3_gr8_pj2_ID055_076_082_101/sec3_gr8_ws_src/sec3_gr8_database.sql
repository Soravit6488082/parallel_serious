DROP DATABASE IF EXISTS PhoneShop;
CREATE DATABASE IF NOT EXISTS PhoneShop;
USE PhoneShop;

-- Create the Admin table
CREATE TABLE Admin (
  id INT NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(255) NOT NULL,
  last_name VARCHAR(255) NOT NULL,
  address VARCHAR(255) NOT NULL,
  age INT NOT NULL,
  preferences VARCHAR(255),
  email VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

-- Create the Admin Login table
CREATE TABLE Admin_Login (
  id INT NOT NULL AUTO_INCREMENT,
  admin_id INT NOT NULL,
  username VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(255) NOT NULL,
  login_log VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  FOREIGN KEY (admin_id) REFERENCES Admin(id)
);

-- Create the Product table
CREATE TABLE Product (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  description VARCHAR(255),
  price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  PRIMARY KEY (id)
);

-- Create the Service table
CREATE TABLE Service (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  description VARCHAR(255),
  price DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id)
);